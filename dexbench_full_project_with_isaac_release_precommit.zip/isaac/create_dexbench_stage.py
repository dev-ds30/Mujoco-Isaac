print('stub')
